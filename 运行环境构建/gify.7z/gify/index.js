/**
 * Module dependencies.
 * v0.1
 */

var exec = require('child_process').exec;
var escape = require('shell-escape');
//var debug = require('debug')('gify');
var mkdirp = require('mkdirp');
var uid = require('uid2');
const logger = require('../../src/logger');

/**
 * Expose `gify()`.
 */

module.exports = gify;

/**
 * Convert `input` file to `output` gif with the given `opts`:
 *
 *  - `width` max width [500]
 *  - `height` max height [none]
 *  - `delay` between frames [0]
 *  - `rate` frame rate [10]
 *  - `start` start position in seconds [0]
 *  - `duration` length of video to convert [auto]
 *
 * @param {Type} name
 * @return {Type}
 * @api public
 */

async function gify(input, output, temp, opts, video, fn) {
    if (!input) throw new Error('input filename required');
    if (!output) throw new Error('output filename required');

    // options
    if ('function' == typeof opts) {
        fn = opts;
        opts = {};
    } else {
        opts = opts || {};
    }

    // dims
    var w = opts.width;
    var h = opts.height;
    var color = opts.color;
    //console.log(color);
    var rate = opts.rate || 12;
    var delay = opts.delay || 'auto';

    // auto delay
    if ('auto' == delay) {
        delay = 1000 / rate / 10 | 0;
    }

    // scale
    var scale;
    if (w) scale = w + ':-1';
    else if (h) scale = '-1:' + h;
    else {
        scale = String(w) + ':-1';
    }

    // tmpfile(s)
    var id = uid(10);
    var dir = temp + '/tmp2/' + id;
    var tmp = dir + '/%04d.jpg';
    //var dir2 = temp + '/tmp2/' + id;;
    //debug('mkdir -p %s', dir);
    await mkdirp(dir, function (err) {
        if (err) return fn(err);
        // convert to gif
        var cmd = ['ffmpeg'];
        cmd.push('-i', input);
        cmd.push('-filter:v', 'scale=' + scale);
        cmd.push('-r', String(rate));
        if (opts.start) cmd.push('-ss', String(opts.start));
        if (opts.duration) cmd.push('-t', String(opts.duration));
        cmd.push(tmp);
        cmd = escape(cmd);
        //console.log(cmd);
        //debug('exec `%s`', cmd);
        exec(cmd, function (err) {
            if (err) return gc(err);
            let cmd;
            cmd = ['gm', 'convert'];
            cmd.push('-delay', String(delay || 0));
            cmd.push('-colors ', String(color));
            cmd.push('-loop', '0');
            cmd.push(temp + "/tmp2/" + id + "/*.jpg");
            cmd.push(output);
            //cmd.push(`& rd /s /q ${dir2}`); //删除临时文件
            //cmd.push('& rm -fr ' + dir2);
            cmd = escape(cmd);
            cmd = cmd.replace(/'/g, "");
            //console.log(cmd);
            //debug('exec `%s`', cmd);
            exec(cmd, action);
        });
    });

    function action(err) {
        if (err) return gc(err);
        if (video == true) {
            logger.info("提取音频");
            //mp4提取音频m4a
            let cmd2 = ['ffmpeg'];
            cmd2.push('-i', input);
            cmd2.push('-vn');
            cmd2.push('-codec', 'copy');
            cmd2.push(input.replace("mp4", "m4a"));
            cmd2 = escape(cmd2);
            cmd2 = cmd2.replace(/'/g, "");
            exec(cmd2, function (err) {
                if (err) return gc(err);
                let cmd;
                cmd = ['ffmpeg', '-i'];
                cmd.push(input.replace("mp4", "m4a"));
                cmd.push(input.replace("mp4", "mp3"));
                //cmd.push(`& rd /s /q ${dir2}`); //删除临时文件
                cmd = escape(cmd);
                cmd = cmd.replace(/'/g, "");
                //console.log(cmd);
                //debug('exec `%s`', cmd);
                exec(cmd, gc);
            });
            //cmd2.push('& ffmpeg -i ' + input.replace("mp4", "m4a") + ' ' + input.replace("mp4", "mp3"));
            //ffmpeg -i 7.mp4 -vn -codec copy 7.m4a
            //https://blog.csdn.net/tomwillow/article/details/90372606
            //m4a转码mp3
            //ffmpeg -i 7.m4a 7.mp3
            //https://blog.csdn.net/ssllkkyyaa/article/details/90400302
        } else {
            logger.info("只是GIF");
            gc(null);
        }
    }

    function gc(err) {
        //debug('remove %s', dir2);
        exec('rm -fr ' + dir); //删除临时文件
        // Remove temp folder
        //exec(`rd /s /q ${dir2}`);
        fn(err);
    }
}
/*
删除文件 del或erase命令
del命令用于删除一个或多个文件，帮助文档如下所示：

c:\users\lan>del /?
删除一个或数个文件。
del [/p] [/f] [/s] [/q] [/a[[:]attributes]] names
erase [/p] [/f] [/s] [/q] [/a[[:]attributes]] names
  names         指定一个或多个文件或者目录列表。
                通配符可用来删除多个文件。
                如果指定了一个目录，该目录中的所
                有文件都会被删除。
  /p            删除每一个文件之前提示确认。
  /f            强制删除只读文件。
  /s            删除所有子目录中的指定的文件。
  /q            安静模式。删除全局通配符时，不要求确认
  /a            根据属性选择要删除的文件
  属性          r  只读文件                     s  系统文件
                h  隐藏文件                     a  存档文件
                i  无内容索引文件               l  重分析点
                -  表示“否”的前缀
如果命令扩展被启用，del 和 erase 更改如下:
/s 开关的显示句法会颠倒，即只显示已经删除的文件，而不显示找不到的文件。

删除一个文件
输入del 文件名即可删除该文件，如:del a.txt。

删除某个后缀的所有文件
输入del *.后缀名就可以删除以后该缀名的所有文件，如要删除掉当前目录下所的所有.html文件:

del *.html
1
删除掉当前目录下的所有.html,.js,.css文件:

del *.html *.js *.css
1
同时，从帮助文档中，我们可以看到，erase命令和del命令的功能一样，所以使用：

erase *.html *.js *.css
1
一样能删除当前目录下的所有.html,.js,.css文件。

删除目录 rmdir或rd命令
rmdir命令用于删除一个目录，cmd中输入rmdir /?查看帮助文档，如下所示:

c:\users\lan>rmdir /?
删除一个目录。
rmdir [/s] [/q] [drive:]path
rd [/s] [/q] [drive:]path
    /s      除目录本身外，还将删除指定目录下的所有子目录和文件。用于删除目录树。
    /q      安静模式，带 /s 删除目录树时不要求确认

同样的,rd命令和rmdir命令一样。以后就直接使用rd命令这样可以少打几次键盘。

删除空目录
如果一个目录时空目录的话，则可以直接使用 rmdir 目录名直接删除即可：
例如:rmdir myjavadoc,如果该目录不是空目录则这样无法删除:

D:\学习9\疯狂Java讲义第三版光盘\codes\03\3.1>rmdir myjavadoc
目录不是空的。

删除非空目录
删除非空目录，需要加上/s参数:

rmdir /s myjavadoc
1
不过为了避免误操作，使用这个命令时,还需要我们输入y进行确认.

D:\学习9\疯狂Java讲义第三版光盘\codes\03\3.1>rmdir /s myjavadoc
myjavadoc, 是否确认(Y/N)? y

直接删除非空目录
如果删除非空目录时，不想再确认，则可以加上/q参数：

rmdir /q /s myjavadoc
1
这样就直接删除掉非空目录myjavadoc了。
当然如果myjavadoc目录时空目录的话加上参数也是能删掉的，但是空目录的话不加参数就可以删掉，加上参数反而画蛇添足。
————————————————
版权声明：本文为CSDN博主「蓝蓝223」的原创文章，遵循CC 4.0 BY-SA版权协议，转载请附上原文出处链接及本声明。
原文链接：https://blog.csdn.net/qq_21808961/java/article/details/86749745
*/