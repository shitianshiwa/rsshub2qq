ZenLib - http://zenlib.sourceforge.net
Copyright (c) MediaArea.net SARL. All Rights Reserved.

This program is freeware under zlib license conditions.
See License.txt for more information
